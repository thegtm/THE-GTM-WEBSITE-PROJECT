
import React from 'react';
import './PopularCourses.css';
import CourseCard from '../components/CourseCard';

const PopularCourses= () => {
  const courses = [
    {
      id: 1,
      title: 'Crop Rotation Fundamentals',
      image: './backgroundimage.jpg',  
      description: 'lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum.',
      rating: 4.2,
      reviews: 188,
      price: '$5.00',
      instructor: {
        name: 'Lorem Ipsum',
        image: '/client/public/greenhouse.jpg',  
      },
      enrolled: 1000,
    },
    {
      id: 1,
      title: 'Crop Rotation Fundamentals',
      image: '/client/public/greenhouse.jpg',  
      description: 'lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum.',
      rating: 4.2,
      reviews: 188,
      price: '$5.00',
      instructor: {
        name: 'Lorem Ipsum',
        image: '/client/public/greenhouse.jpg',  
      },
      enrolled: 1000,
    },
    {
      id: 1,
      title: 'Crop Rotation Fundamentals',
      image: '/client/public/greenhouse.jpg',  
      description: 'lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum.',
      rating: 4.2,
      reviews: 188,
      price: '$5.00',
      instructor: {
        name: 'Lorem Ipsum',
        image: '/client/public/greenhouse.jpg',  
      },
      enrolled: 1000,
    },
    {
      id: 1,
      title: 'Crop Rotation Fundamentals',
      image: '/client/public/greenhouse.jpg',  
      description: 'lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum.',
      rating: 4.2,
      reviews: 188,
      price: '$5.00',
      instructor: {
        name: 'Lorem Ipsum',
        image: '/client/public/greenhouse.jpg',  
      },
      enrolled: 1000,
    },
    {
      id: 1,
      title: 'Crop Rotation Fundamentals',
      image: '/client/public/greenhouse.jpg',  
      description: 'lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum.',
      rating: 4.2,
      reviews: 188,
      price: '$5.00',
      instructor: {
        name: 'Lorem Ipsum',
        image: '/client/public/greenhouse.jpg',  
      },
      enrolled: 1000,
    },
    {
      id: 1,
      title: 'Crop Rotation Fundamentals',
      image: '/client/public/greenhouse.jpg',  
      description: 'lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum.',
      rating: 4.2,
      reviews: 188,
      price: '$5.00',
      instructor: {
        name: 'Lorem Ipsum',
        image: '/client/public/greenhouse.jpg',  
      },
      enrolled: 1000,
    },
    {
      id: 1,
      title: 'Crop Rotation Fundamentals',
      image: '/client/public/greenhouse.jpg',  
      description: 'lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum.',
      rating: 4.2,
      reviews: 188,
      price: '$5.00',
      instructor: {
        name: 'Lorem Ipsum',
        image: '/client/public/greenhouse.jpg',  
      },
      enrolled: 1000,
    },
    {
      id: 1,
      title: 'Crop Rotation Fundamentals',
      image: '/client/public/greenhouse.jpg',  
      description: 'lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum.',
      rating: 4.2,
      reviews: 188,
      price: '$5.00',
      instructor: {
        name: 'Lorem Ipsum',
        image: '/client/public/greenhouse.jpg',  
      },
      enrolled: 1000,
    },
    {
      id: 1,
      title: 'Crop Rotation Fundamentals',
      image: '/client/public/greenhouse.jpg',  
      description: 'lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum.',
      rating: 4.2,
      reviews: 188,
      price: '$5.00',
      instructor: {
        name: 'Lorem Ipsum',
        image: '/client/public/greenhouse.jpg',  
      },
      enrolled: 1000,
    },
    
    
  ];

  

  return (
    <section className="courses-section">
      <h2>Our Popular Courses</h2>
      <div className='header-description'>
        <p >Lorem ipsum lorem ipsum lorem ipsum lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum.</p>
      </div>
  
      <div className="course-grid">
        {courses.map((course, index) => (
          < CourseCard key={index} {...course} />
        ))}
      </div>
      <div className="pagination">
        <button>1</button>
        <button>2</button>
        <button>3</button>
        <button>4</button>
      </div>
    </section>
  );
};

export default PopularCourses;
