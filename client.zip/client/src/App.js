import Footer from './components/Footer';
import  NavBar from'./components/Navbar';
import './App.css';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import PopularCourses from './pages/PopularCourses';
import SignIn from './pages/SignIn';
import Register from './pages/Register';
import Resetpassword from './pages/Resetpassword';


function App() {
  return (
    <Router>
      <div className="App">
        <NavBar/>
        <main>
          <Routes>
            <Route exact path="/" element={<PopularCourses />} />
            <Route exact path="/SignIn" element={<SignIn/>} />
            <Route exact path="/register" element={<Register/>} />
            <Route exact path="/reset-password" element={<Resetpassword/>} />
          </Routes>
        </main>
        
        
        <Footer />
      </div>
    </Router>
  );
  
}

export default App;
